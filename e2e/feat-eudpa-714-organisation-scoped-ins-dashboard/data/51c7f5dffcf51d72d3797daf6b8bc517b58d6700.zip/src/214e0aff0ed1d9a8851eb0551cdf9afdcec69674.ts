import { type Locator } from '@playwright/test';
import { speciesLabel, type CommodityLine } from '@domain/animals/constants/commodity-lines';
import { NotificationPage } from '@page-objects/shared/base-page';
import { SelectedCommoditiesTable } from '@page-objects/animals/selected-commodities-table';

export class AnimalsConsignmentDetailsPage extends NotificationPage {
  readonly selectedCommodities = new SelectedCommoditiesTable(this.page);

  constructor(page: ConstructorParameters<typeof NotificationPage>[0]) {
    super(page, 'consignment-details');
  }

  get heading(): Locator {
    return this.page.getByRole('heading', { level: 1, name: 'Commodity details' });
  }

  get numberOfAnimals(): Locator {
    return this.page.getByLabel('Number of animals');
  }

  get numberOfPackages(): Locator {
    return this.page.getByLabel('Number of packages (when required)');
  }

  get addAnotherCommodity(): Locator {
    return this.page.getByRole('link', { name: 'Add another commodity' });
  }

  get animalsRequiredErrorLink(): Locator {
    return this.page.getByRole('link', { name: 'Enter the number of animals' });
  }

  get animalsAboveMaxErrorLink(): Locator {
    return this.page.getByRole('link', {
      name: 'Number of animals must be 2,147,483,647 or fewer',
    });
  }

  get caption(): Locator {
    return this.page.getByText('Description of the goods', { exact: true });
  }

  get headingBelowCaption(): Locator {
    return this.caption.locator('xpath=following-sibling::*[1]');
  }

  async numberOfAnimalsFor(species: CommodityLine): Promise<Locator> {
    return this.numberOfAnimals.nth(await this.speciesPosition(species));
  }

  async numberOfPackagesFor(species: CommodityLine): Promise<Locator> {
    return this.numberOfPackages.nth(await this.speciesPosition(species));
  }

  async fillAnimalCountFor(species: CommodityLine, count: number): Promise<void> {
    await (await this.numberOfAnimalsFor(species)).fill(String(count));
  }

  async fillPackageCountFor(species: CommodityLine, count: number): Promise<void> {
    await (await this.numberOfPackagesFor(species)).fill(String(count));
  }

  private async speciesPosition(species: CommodityLine): Promise<number> {
    const label = speciesLabel(species);
    const speciesHeadings = await this.page.getByRole('heading', { level: 3 }).allTextContents();
    const index = speciesHeadings.indexOf(label);
    if (index === -1) {
      throw new Error(`No "${label}" heading among: ${speciesHeadings.join(', ')}`);
    }
    return index;
  }

  async fillEveryAnimalCount(count: string): Promise<void> {
    for (const box of await this.numberOfAnimals.all()) {
      await box.fill(count);
    }
  }

  async fillEveryPackageCount(count: string): Promise<void> {
    for (const box of await this.numberOfPackages.all()) {
      await box.fill(count);
    }
  }
}
