import { randomUUID } from 'node:crypto';
import { test, expect } from '@fixtures';
import { WHOLE_REFERENCE_NUMBER_PATTERN } from '@domain/plants/constants/reference-number-patterns';
import { portByCode } from '@resources/reference-data/reference-data';
import { NOT_YET_ARRIVED } from '@domain/plants/constants/arrival-status-page';
import { COLD_START } from '@fixtures/auth-state';
import { PLANTS_FOR_PLANTING, POTATOES, WOOD_AND_CUT_TREES, arrivalDate, nurseryAddress, type CommodityLine } from '@flows/plants/journey';

const scenarios: { name: string; type: string; category: string; country: string; late: boolean; line: CommodityLine }[] = [
  {
    name: 'ware potatoes from Spain before arrival',
    type: POTATOES,
    category: 'Ware potatoes',
    country: 'Spain',
    late: false,
    line: { Variety: 'Maris Piper', Quantity: '250', 'Intended use': 'Eating' },
  },
  {
    name: 'ware potatoes from Portugal notified late',
    type: POTATOES,
    category: 'Ware potatoes',
    country: 'Portugal',
    late: true,
    line: { Variety: 'Maris Piper', Quantity: '250', 'Intended use': 'Eating' },
  },
  {
    name: 'seed potatoes from the Netherlands',
    type: POTATOES,
    category: 'Seed potatoes',
    country: 'Netherlands (the)',
    late: false,
    line: { Variety: 'Maris Piper', Quantity: '250', 'Intended use': 'Planting' },
  },
  {
    name: 'spruce from Germany with species and EPPO code',
    type: PLANTS_FOR_PLANTING,
    category: PLANTS_FOR_PLANTING,
    country: 'Germany',
    late: false,
    line: { Genus: 'Picea (spruce)', Species: 'Picea abies', 'Commodity code': '0602 20 20', Quantity: '40', 'EPPO code': 'PIEAB' },
  },
  {
    name: 'conifer wood without bark from Italy with treatments',
    type: WOOD_AND_CUT_TREES,
    category: 'Conifer wood without bark (from Italy, France, Portugal or Spain)',
    country: 'Italy',
    late: false,
    line: { 'Commodity code': '4403 21 10', Quantity: '12', 'Phytosanitary treatments applied': 'Kiln dried (KD)' },
  },
];

test.use({ storageState: COLD_START });

test.describe('High-risk plants full happy-path journeys', () => {
  for (const scenario of scenarios) {
    test(`${scenario.name}: sign in, submit and view the saved notification`, async ({
      pages,
      plantsPages,
      plantsJourney,
      addressBookApi,
    }) => {
      const address = await addressBookApi.createAddress(nurseryAddress(`Journey Nursery ${randomUUID()}`));
      const expectedArrival = arrivalDate(scenario.late ? -1 : 7);
      const reference = await plantsJourney.startNotification();
      expect(reference).toMatch(WHOLE_REFERENCE_NUMBER_PATTERN);
      await plantsJourney.chooseCommodityType(scenario.type);
      await plantsJourney.addCommodityLine(scenario.category, scenario.line);
      await plantsJourney.toOrigin();
      if (scenario.type === POTATOES) {
        await plantsJourney.toArrivalDetails(scenario.country);
        await plantsPages.arrivalDetails.arrivalTime.fill('14:30');
        await plantsPages.arrivalDetails.placeOfLanding.choose(portByCode('GB ABD').display);
      } else {
        await plantsJourney.toArrivalStatus(scenario.country);
        await plantsJourney.answerArrivalStatus(NOT_YET_ARRIVED);
      }
      await plantsPages.arrivalDetails.arrivalDate.fill(expectedArrival);
      await plantsPages.arrivalDetails.saveAndContinue.click();
      await plantsJourney.chooseDestination(address.name);
      if (scenario.type !== POTATOES) {
        await plantsPages.consignorSelect.searchFor(address.name);
        await plantsPages.consignorSelect.address(address.name).check();
        await plantsPages.consignorSelect.saveAndContinue.click();
      }
      if (scenario.type === POTATOES) {
        await plantsPages.identificationNumbers.producer.fill('P123');
        await plantsPages.identificationNumbers.crop.fill('C123');
      } else if (scenario.type === PLANTS_FOR_PLANTING) {
        await plantsPages.identificationNumbers.supplier.fill('DE-12345');
      }
      await plantsPages.identificationNumbers.consignment.fill('JOURNEY_123');
      await plantsPages.identificationNumbers.saveAndContinue.click();
      await plantsPages.consignmentContactSelect.searchFor(address.name);
      await plantsPages.consignmentContactSelect.address(address.name).check();
      await plantsPages.consignmentContactSelect.saveAndContinue.click();
      await expect(pages.page).toHaveURL(plantsPages.notificationView.expectedUrlPattern(reference));
      await expect(plantsPages.notificationView.heading).toBeVisible();
      await plantsPages.notificationView.btnContinue.click();
      await expect(pages.page).toHaveURL(plantsPages.declaration.expectedUrlPattern(reference));
      await plantsPages.declaration.checkbox.check();
      await plantsPages.declaration.btnContinue.click();

      await expect(pages.page).toHaveURL(plantsPages.confirmation.expectedUrlPattern(reference));
      await expect(plantsPages.confirmation.heading).toBeVisible();
      await expect(plantsPages.confirmation.panel).toContainText(reference);
      await expect(plantsPages.confirmation.lateBanner).toHaveCount(scenario.late ? 1 : 0);
      await plantsPages.confirmation.viewNotification.click();
      await pages.page.reload();
      await expect(pages.page).toHaveURL(plantsPages.notificationView.expectedUrlPattern(reference));
      await expect(plantsPages.notificationView.heading).toBeVisible();
      await expect(plantsPages.overview.notificationReference).toHaveText(reference);
      await expect(plantsPages.overview.statusTag).toHaveText('Submitted');
      await expect(plantsPages.notificationView.changeLinks).toHaveCount(0);
      await expect(plantsPages.notificationView.btnContinue).toHaveCount(0);
      await expect(plantsPages.notificationView.lateBanner).toHaveCount(scenario.late ? 1 : 0);
      await expect(plantsPages.notificationView.card('Import details')).toContainText(scenario.country);
      const commodity = plantsPages.notificationView.card('Commodity 1');
      await expect(commodity).toContainText(scenario.category);
      for (const value of Object.values(scenario.line)) {
        await expect(commodity).toContainText(value);
      }
      await expect(plantsPages.notificationView.card('Arrival details')).toContainText(expectedArrival);
      await expect(plantsPages.notificationView.card('Place of destination')).toContainText(address.name);
      await expect(plantsPages.notificationView.card('Identification numbers')).toContainText('JOURNEY_123');
      await expect(plantsPages.notificationView.card('Contact')).toContainText(address.name);
      await expect(plantsPages.notificationView.card('Contact')).toContainText(address.email);
      if (scenario.type !== POTATOES) {
        await expect(plantsPages.notificationView.card('Consignor')).toContainText(address.name);
      }
      await plantsPages.dashboard.open();
      await plantsPages.dashboard.searchForReference(reference);
      await expect(plantsPages.dashboard.notificationCard(reference)).toBeVisible();
      await expect(plantsPages.dashboard.cardStatusTag(reference)).toHaveText('Submitted');
    });
  }
});
