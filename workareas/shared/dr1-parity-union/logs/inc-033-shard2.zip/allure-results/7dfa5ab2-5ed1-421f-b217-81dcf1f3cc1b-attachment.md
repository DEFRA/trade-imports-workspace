# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: e2e/pages/commodities.spec.ts >> Commodity selection page >> accepts and persists multiple commodity-species pairs found under different queries
- Location: tests/e2e/pages/commodities.spec.ts:48:3

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('#commodity-selection')
Expected substring: "2 selected"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" with timeout 5000ms
  - waiting for locator('#commodity-selection')

```

```yaml
- link "Skip to main content":
  - /url: "#main-content"
- banner:
  - link "GOV.UK":
    - /url: https://www.gov.uk/
    - img "GOV.UK"
  - region "Service information":
    - link "Import notification service":
      - /url: /
    - navigation "Menu":
      - list:
        - listitem:
          - link "Dashboard":
            - /url: /
            - strong: Dashboard
        - listitem:
          - link "Address book":
            - /url: "#"
        - listitem:
          - link "Manage account":
            - /url: "#"
        - listitem:
          - link "Log out":
            - /url: /auth/sign-out
- paragraph:
  - strong: Alpha
  - text: This is a new service. Help us improve it and
  - link "give your feedback by email":
    - /url: mailto:APHAServiceDesk@apha.gov.uk
  - text: .
- link "Back":
  - /url: /
- main:
  - strong: Draft
  - text: GBN-AG-26-EY8ADK
  - heading "Overview" [level=1]
  - heading "Your commodities" [level=2]
  - paragraph: "0"
  - heading "Animals" [level=3]
  - paragraph: Total number of animals in this consignment
  - paragraph: "0"
  - heading "Packages/boxes" [level=3]
  - paragraph: Total number of packages in this consignment
  - heading "1. About the consignment" [level=2]
  - list:
    - listitem:
      - link "Where is this consignment coming from?":
        - /url: /notifications/GBN-AG-26-EY8ADK/origin
      - text: Country of origin, region of origin code, your internal reference
      - strong: Completed
    - listitem:
      - link "What are you importing?":
        - /url: /notifications/GBN-AG-26-EY8ADK/commodities
      - text: The commodities and species you are importing
      - strong: Completed
    - listitem:
      - link "Main reason for importing":
        - /url: /notifications/GBN-AG-26-EY8ADK/import-reason
      - text: Why you are importing the animals and their purpose in the internal market
      - strong: Not yet started
  - heading "2. Commodity details" [level=2]
  - list:
    - listitem:
      - link "Commodity details":
        - /url: /notifications/GBN-AG-26-EY8ADK/consignment-details
      - text: How many animals and packages there are for each commodity
      - strong: Not yet started
    - listitem:
      - link "Additional commodity details":
        - /url: /notifications/GBN-AG-26-EY8ADK/additional-details
      - text: What the animals are certified for and whether any are unweaned
      - strong: Not yet started
    - listitem:
      - link "Animal identification details":
        - /url: /notifications/GBN-AG-26-EY8ADK/commodities/identification
      - text: Identification details for the animals in each commodity
      - strong: Not yet started
  - heading "3. Movement" [level=2]
  - list:
    - listitem:
      - link "Arrival details":
        - /url: /notifications/GBN-AG-26-EY8ADK/port-of-entry
      - text: The port of entry, when the consignment will arrive and how the animals will travel
      - strong: Not yet started
    - listitem:
      - link "Transporter":
        - /url: /notifications/GBN-AG-26-EY8ADK/transporters
      - text: Who transports the animals to their destination
      - strong: Not yet started
  - heading "4. Addresses" [level=2]
  - list:
    - listitem:
      - link "Roles and addresses":
        - /url: /notifications/GBN-AG-26-EY8ADK/addresses
      - text: The consignor, consignee, importer and the places of origin and destination
      - strong: Not yet started
    - listitem:
      - link "Contact address":
        - /url: /notifications/GBN-AG-26-EY8ADK/consignment/contact/select
      - text: Who we should contact about this notification
      - strong: Not yet started
  - heading "5. Documents" [level=2]
  - list:
    - listitem:
      - link "Uploaded documents":
        - /url: /notifications/GBN-AG-26-EY8ADK/accompanying-documents
      - text: Certificates, permits and other documents for the consignment Optional
  - heading "6. Check and submit" [level=2]
  - list:
    - listitem: Check and submit Check your answers before you submit the notification Cannot start yet
  - button "Return to dashboard"
- contentinfo:
  - heading "Support links" [level=2]
  - list:
    - listitem:
      - link "Privacy":
        - /url: https://www.gov.uk/help/privacy-notice
    - listitem:
      - link "Cookies":
        - /url: https://www.gov.uk/help/cookies
    - listitem:
      - link "Accessibility statement":
        - /url: https://www.gov.uk/help/accessibility-statement
  - text: All content is available under the
  - link "Open Government Licence v3.0":
    - /url: https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/
  - text: ", except where otherwise stated"
  - link "© Crown copyright":
    - /url: https://www.nationalarchives.gov.uk/information-management/re-using-public-sector-information/uk-government-licensing-framework/crown-copyright/
```

# Test source

```ts
  1  | import { test, expect } from '@fixtures';
  2  | 
  3  | // The page holds nothing until a query reaches it, so each commodity is found
  4  | // by its own code. Cat and Dog share 01061900, so that query returns both.
  5  | const expectedGroups = [
  6  |   ['Cow (0102)', '0102', ['Bison bison', 'Bos spp.', 'Bos taurus', 'Bubalus bubalis']],
  7  |   ['Horse (0101)', '0101', ['Equus caballus']],
  8  |   ['Cat (01061900)', '01061900', ['Felis catus']],
  9  |   ['Dog (01061900)', '01061900', ['Canis lupus familiaris']],
  10 |   ['Fish (0301)', '0301', ['Salmo salar']],
  11 | ] as const;
  12 | 
  13 | test.describe('Commodity selection page', { tag: ['@integration', '@duplicated-in-frontend'] }, () => {
  14 |   test.beforeEach(async ({ journey }) => {
  15 |     await journey.toCommoditySelection();
  16 |   });
  17 | 
  18 |   test('offers a search box and lists nothing until it is used', async ({ pages }) => {
  19 |     await expect(pages.commoditySelection.heading).toBeVisible();
  20 |     await expect(pages.commoditySelection.searchBox).toBeVisible();
  21 |     await expect(pages.page.getByRole('checkbox')).toHaveCount(0);
  22 |     await expect(pages.commoditySelection.selectionPanel).toHaveCount(0);
  23 |     await expect(pages.commoditySelection.saveAndContinue).toBeVisible();
  24 |   });
  25 | 
  26 |   test('lists nothing for a query shorter than three characters', async ({ pages }) => {
  27 |     await pages.commoditySelection.search('Bo');
  28 |     await expect(pages.page.getByRole('checkbox')).toHaveCount(0);
  29 |   });
  30 | 
  31 |   test('groups the matching species under their commodity heading', async ({ pages }) => {
  32 |     for (const [legend, query, species] of expectedGroups) {
  33 |       await pages.commoditySelection.search(query);
  34 |       const group = pages.page.getByRole('group', { name: legend });
  35 |       await expect(group).toBeVisible();
  36 |       for (const name of species) {
  37 |         await expect(group.getByRole('checkbox', { name })).toBeVisible();
  38 |       }
  39 |     }
  40 |   });
  41 | 
  42 |   test('says so when nothing matches', async ({ pages }) => {
  43 |     await pages.commoditySelection.search('zzz');
  44 |     await expect(pages.page.getByText('No results found')).toBeVisible();
  45 |     await expect(pages.page.getByRole('checkbox')).toHaveCount(0);
  46 |   });
  47 | 
  48 |   test('accepts and persists multiple commodity-species pairs found under different queries', async ({ pages }) => {
  49 |     test.slow();
  50 | 
  51 |     await pages.commoditySelection.selectSpecies(['Bos taurus', 'Felis catus']);
  52 |     await pages.commoditySelection.saveAndContinue.click();
  53 |     await expect(pages.page.getByRole('heading', { name: 'There is a problem' })).toHaveCount(0);
  54 | 
  55 |     // Back on the page, both pairs are listed under the running count without
  56 |     // any query — a choice made under an earlier query is never lost.
  57 |     await pages.consignmentDetails.linkBack.click();
> 58 |     await expect(pages.commoditySelection.selectionPanel).toContainText('2 selected');
     |                                                           ^ Error: expect(locator).toContainText(expected) failed
  59 |     await expect(pages.commoditySelection.selectionPanel).toContainText('Bos taurus');
  60 |     await expect(pages.commoditySelection.selectionPanel).toContainText('Felis catus');
  61 | 
  62 |     // And each is ticked again when its own query brings it back on screen.
  63 |     await pages.commoditySelection.search('Bos taurus');
  64 |     await expect(pages.commoditySelection.species('Bos taurus')).toBeChecked();
  65 |     await pages.commoditySelection.search('Felis catus');
  66 |     await expect(pages.commoditySelection.species('Felis catus')).toBeChecked();
  67 |   });
  68 | 
  69 |   test('counts what has been chosen and clears it on request', async ({ pages }) => {
  70 |     await pages.commoditySelection.selectSpecies(['Bos taurus']);
  71 |     // The panel is written on the server, so it appears on the next render.
  72 |     await pages.commoditySelection.search('Salmo');
  73 |     await expect(pages.commoditySelection.selectionPanel).toContainText('1 selected');
  74 |     await expect(pages.commoditySelection.selectionPanel).toContainText('Bos taurus');
  75 | 
  76 |     await pages.commoditySelection.clearAll.click();
  77 |     await expect(pages.commoditySelection.selectionPanel).toHaveCount(0);
  78 |   });
  79 | 
  80 |   test('shows an error summary when submitted empty', async ({ pages }) => {
  81 |     await pages.commoditySelection.saveAndContinue.click();
  82 |     await expect(pages.page.getByRole('heading', { name: 'There is a problem' })).toBeVisible();
  83 |     await expect(pages.page.getByRole('link', { name: 'Select a commodity' })).toBeVisible();
  84 |   });
  85 | });
  86 | 
```