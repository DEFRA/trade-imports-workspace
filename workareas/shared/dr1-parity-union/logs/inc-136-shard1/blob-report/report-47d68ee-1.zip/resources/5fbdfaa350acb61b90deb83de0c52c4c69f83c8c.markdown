# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: e2e/features/documents-scan-lifecycle.spec.ts >> Documents scan lifecycle >> clean upload: shows Checking with no view link, then Safe with a view link
- Location: tests/e2e/features/documents-scan-lifecycle.spec.ts:34:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.govuk-table__row').filter({ hasText: 'PWSCAN1788889315746' })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for locator('.govuk-table__row').filter({ hasText: 'PWSCAN1788889315746' })

```

```yaml
- link "Skip to main content":
  - /url: "#main-content"
- banner:
  - link "GOV.UK":
    - /url: https://www.gov.uk/
    - img "GOV.UK"
  - region "Service information":
    - link "Import notification service":
      - /url: /
    - navigation "Menu":
      - list:
        - listitem:
          - link "Dashboard":
            - /url: /
            - strong: Dashboard
        - listitem:
          - link "Address book":
            - /url: "#"
        - listitem:
          - link "Manage account":
            - /url: "#"
        - listitem:
          - link "Log out":
            - /url: /auth/sign-out
- paragraph:
  - strong: Alpha
  - text: This is a new service. Help us improve it and
  - link "give your feedback by email":
    - /url: mailto:APHAServiceDesk@apha.gov.uk
  - text: .
- link "Back":
  - /url: /notifications/GBN-AG-26-P65CRY
- main:
  - strong: Draft
  - text: GBN-AG-26-P65CRY
  - alert:
    - heading "There is a problem" [level=2]
    - list:
      - listitem:
        - link "Select a document type":
          - /url: "#accompanyingDocumentType"
  - text: Documents
  - heading "Upload documents" [level=1]
  - paragraph: You must attach an ITAHC if this consignment requires one. If you do not have it now, you can add it later. All documents should be uploaded before the consignment arrives at the UK port. Documents must be in English and you must upload all pages.
  - paragraph: "Other documents you may need to attach include:"
  - list:
    - listitem: import licences or authorisations
    - listitem: commercial documents or invoices
  - group: Check which additional documents you must upload
  - region "File upload":
    - heading "File upload" [level=2]
    - text: Document reference For example, GBHC1234567890.
    - textbox "Document reference": PWSCAN1788889315746
    - text: Document type
    - paragraph: "Error: Select a document type"
    - combobox "Document type":
      - option "Select one" [selected]
      - option "Intra Trade Animal Health Certificate (ITAHC)"
      - option "Veterinary health certificate"
      - option "Air waybill"
      - option "Import permit"
      - option "Letter of authority (Directive 2008/61/EC)"
      - option "Commercial invoice"
      - option "Sea waybill"
      - option "Rail waybill"
      - option "Bill of lading"
      - option "Catch certificate"
      - option "Laboratory sampling results for aflatoxin (Reg 2019/1793)"
      - option "Journey log"
      - option "Other"
    - text: Date of issue For example, 12/12/2025
    - textbox "Date of issue": 03/01/2026
    - button "Choose date"
    - text: Upload a file
    - paragraph: "Your file must be:"
    - list:
      - listitem: smaller than 10 MB
      - listitem: a PDF, DOC, DOCX, JPEG, PNG, XLS or XLSX
    - button "Upload a file"
    - button "Save and add another"
    - paragraph: You have not added any documents yet.
  - button "Continue"
  - button "Save and return to overview"
  - link "Cancel and return to overview":
    - /url: /notifications/GBN-AG-26-P65CRY
- contentinfo:
  - heading "Support links" [level=2]
  - list:
    - listitem:
      - link "Privacy":
        - /url: https://www.gov.uk/help/privacy-notice
    - listitem:
      - link "Cookies":
        - /url: https://www.gov.uk/help/cookies
    - listitem:
      - link "Accessibility statement":
        - /url: https://www.gov.uk/help/accessibility-statement
  - text: All content is available under the
  - link "Open Government Licence v3.0":
    - /url: https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/
  - text: ", except where otherwise stated"
  - link "© Crown copyright":
    - /url: https://www.nationalarchives.gov.uk/information-management/re-using-public-sector-information/uk-government-licensing-framework/crown-copyright/
```

# Test source

```ts
  1  | import path from 'node:path';
  2  | import { test, expect } from '@fixtures';
  3  | import { fileUploadPaths } from '@resources/file-upload/paths';
  4  | import { fileUploadTimeouts } from '@config/file-upload-timeouts';
  5  | import { writeEicarPdfFile } from '@utils/eicar-file-writer';
  6  | 
  7  | const issueDate = '03/01/2026';
  8  | 
  9  | test.describe('Documents scan lifecycle', { tag: ['@integration', '@duplicated-in-frontend'] }, () => {
  10 |   test.beforeEach(async ({ journey }) => {
  11 |     await journey.toAccompanyingDocuments();
  12 |   });
  13 | 
  14 |   test('infected upload: accepted with Checking, then Virus found with error summary and no view link', async ({ pages }, testInfo) => {
  15 |     test.slow();
  16 |     const eicar = await writeEicarPdfFile(path.join(testInfo.outputDir, 'file-upload'));
  17 | 
  18 |     const reference = `PWVIRUS${Date.now()}`;
  19 |     await pages.accompanyingDocuments.fillDocument(reference, issueDate, eicar.filePath);
  20 |     await pages.accompanyingDocuments.saveAndAddAnother.click();
  21 | 
  22 |     const row = pages.accompanyingDocuments.documentRow(reference);
  23 |     await expect(row).toBeVisible();
  24 |     await expect(row).toContainText('Checking');
  25 | 
  26 |     await expect(row).toContainText('Virus found', { timeout: fileUploadTimeouts.virusScanComplete });
  27 |     await expect(pages.page.getByRole('heading', { name: 'There is a problem' })).toBeVisible();
  28 |     await expect(
  29 |       pages.page.getByText(`${eicar.fileName} contains a virus. Remove it and try again with a different file.`).first(),
  30 |     ).toBeVisible();
  31 |     await expect(pages.accompanyingDocuments.viewFile(1)).toHaveCount(0);
  32 |   });
  33 | 
  34 |   test('clean upload: shows Checking with no view link, then Safe with a view link', async ({ pages }) => {
  35 |     test.slow();
  36 |     const reference = `PWSCAN${Date.now()}`;
  37 |     await pages.accompanyingDocuments.fillDocument(reference, issueDate, fileUploadPaths.safeFile1kbPdf);
  38 |     await pages.accompanyingDocuments.saveAndAddAnother.click();
  39 | 
  40 |     const row = pages.accompanyingDocuments.documentRow(reference);
> 41 |     await expect(row).toBeVisible();
     |                       ^ Error: expect(locator).toBeVisible() failed
  42 |     await expect(row).toContainText('Checking');
  43 |     await expect(pages.accompanyingDocuments.viewFile(1)).toHaveCount(0);
  44 |     await expect(pages.accompanyingDocuments.removeDocument(1)).toBeVisible();
  45 | 
  46 |     await expect(row).toContainText('Safe', { timeout: fileUploadTimeouts.virusScanComplete });
  47 |     await expect(pages.accompanyingDocuments.viewFile(1)).toBeVisible();
  48 |   });
  49 | });
  50 | 
```